"""Emit LaTeX table fragments from frozen evaluation JSON."""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EVAL = ROOT / "results" / "evaluation" / "evaluation_report.json"
GRID = ROOT / "results" / "evaluation" / "grid_search.json"
OUT = ROOT / "paper" / "generated"


def fmt(x: float, digits: int = 2) -> str:
    return f"{x:.{digits}f}"


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    report = json.loads(EVAL.read_text())
    grid = json.loads(GRID.read_text())

    m = report["metrics"]
    dm = report["diebold_mariano_test"]

    table1 = r"""
\begin{table}[ht]
  \centering
  \caption{Out-of-sample forecast accuracy on the test period (2021Q1--2024Q4).}
  \label{tab:benchmark}
  \begin{tabular}{lrrr}
    \toprule
    Model & RMSE & MAE & $N$ \\
    \midrule
    ST-GNN (rolling refit) & %s & %s & %d \\
    ARIMA(0,1,1)           & %s & %s & %d \\
    VAR(4)                 & %s & %s & %d \\
    \bottomrule
  \end{tabular}
  \vspace{0.5em}
  \begin{minipage}{\linewidth}
    \footnotesize
    \textit{Notes:} ST-GNN uses expanding-window refit with Huber loss and persistence skip connection.
    VAR excludes Argentina; $N=292$ for VAR and Diebold--Mariano comparisons.
    ST-GNN RMSE excluding Argentina: %s.
  \end{minipage}
\end{table}
""" % (
        fmt(m["stgnn_rolling_test"]["rmse"]),
        fmt(m["stgnn_rolling_test"]["mae"]),
        int(m["stgnn_rolling_test"]["n"]),
        fmt(m["arima_test"]["rmse"]),
        fmt(m["arima_test"]["mae"]),
        int(m["arima_test"]["n"]),
        fmt(m["var_test"]["rmse"]),
        fmt(m["var_test"]["mae"]),
        int(m["var_test"]["n"]),
        fmt(m["stgnn_rolling_test_excl_ARG"]["rmse"]),
    )

    table2 = r"""
\begin{table}[ht]
  \centering
  \caption{Diebold--Mariano tests: ST-GNN vs.\ baselines (squared forecast errors, $h=1$).}
  \label{tab:dm}
  \begin{tabular}{lrrr}
    \toprule
    Comparison & DM statistic & $p$-value & $N$ \\
    \midrule
    ST-GNN vs.\ ARIMA & %s & %s & %d \\
    ST-GNN vs.\ VAR   & %s & %s & %d \\
    \bottomrule
  \end{tabular}
  \vspace{0.5em}
  \begin{minipage}{\linewidth}
    \footnotesize
    \textit{Notes:} Paired on test-period observations with non-missing ARIMA and VAR forecasts ($N=%d$).
    Negative statistic implies lower average squared error for ST-GNN.
  \end{minipage}
\end{table}
""" % (
        fmt(dm["stgnn_vs_arima_squared"]["statistic"], 3),
        fmt(dm["stgnn_vs_arima_squared"]["p_value"], 3),
        int(dm["stgnn_vs_arima_squared"]["n"]),
        fmt(dm["stgnn_vs_var_squared"]["statistic"], 3),
        fmt(dm["stgnn_vs_var_squared"]["p_value"], 3),
        int(dm["stgnn_vs_var_squared"]["n"]),
        int(report["paired_test_rows"]),
    )

    rows = []
    for row in sorted(grid, key=lambda r: r["val_rmse"]):
        rows.append(
            f"    {row['lr']:.4f} & {row['dropout']:.1f} & {row['gcn_layers']} & {row['val_rmse']:.3f} \\\\"
        )
    table_a1 = r"""
\begin{longtable}{rrrr}
  \caption{Hyperparameter grid search on validation RMSE (2019Q1--2020Q4).}
  \label{tab:grid} \\
  \toprule
  Learning rate & Dropout & GCN layers & Val RMSE \\
  \midrule
  \endfirsthead
  \toprule
  Learning rate & Dropout & GCN layers & Val RMSE \\
  \midrule
  \endhead
""" + "\n".join(rows) + r"""
  \bottomrule
\end{longtable}
"""

    (OUT / "table1.tex").write_text(table1.strip())
    (OUT / "table2.tex").write_text(table2.strip())
    (OUT / "table_a1.tex").write_text(table_a1.strip())
    print(f"Wrote LaTeX tables to {OUT}/")


if __name__ == "__main__":
    main()
