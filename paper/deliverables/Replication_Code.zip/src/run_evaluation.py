"""Milestone 7: Hyperparameter tuning, rolling refit ST-GNN, Diebold-Mariano tests."""

from __future__ import annotations

import itertools
import json
from datetime import datetime, timezone

import numpy as np
import pandas as pd
import torch

from src.config import DATA_PROCESSED, RESULTS, ensure_dirs, load_protocol
from src.run_baselines import compute_metrics
from src.stgnn_data import load_panel_tensors, timesteps_for_split
from src.stgnn_model import GCN_LSTM
from src.stgnn_train import (
    TrainConfig,
    build_edge_lists,
    diebold_mariano,
    predict_timesteps,
    rolling_eval,
    set_seed,
    train_on_timesteps,
)

OUT_DIR = RESULTS / "evaluation"
STGNN_DIR = RESULTS / "stgnn"
BASELINE_DIR = RESULTS / "baselines"

GRID = {
    "lr": [5e-4, 1e-3, 3e-3],
    "dropout": [0.2, 0.3, 0.4],
    "gcn_layers": [1, 2],
}


def grid_search(
    x_raw: np.ndarray,
    y: np.ndarray,
    target_mask: np.ndarray,
    train_idx: np.ndarray,
    val_idx: np.ndarray,
    edge_indices: list,
    edge_weights: list,
    device: torch.device,
    in_features: int,
) -> TrainConfig:
    best_cfg = None
    best_val_rmse = float("inf")
    results = []

    combos = list(itertools.product(GRID["lr"], GRID["dropout"], GRID["gcn_layers"]))
    print(f"Phase 1a: Grid search ({len(combos)} configs on val RMSE)...")

    for lr, dropout, gcn_layers in combos:
        set_seed()
        cfg = TrainConfig(lr=lr, dropout=dropout, gcn_layers=gcn_layers, max_epochs=60, patience=10)
        model = GCN_LSTM(in_features, cfg.gcn_hidden, cfg.lstm_hidden, cfg.gcn_layers, cfg.dropout).to(device)
        train_on_timesteps(
            model, x_raw, y, target_mask, list(train_idx), edge_indices, edge_weights, cfg, device,
            val_timesteps=list(val_idx),
        )

        _, val_preds = predict_timesteps(
            model, x_raw, y, target_mask, edge_indices, edge_weights, list(val_idx), device,
            norm_timesteps=list(train_idx),
        )
        if val_preds.empty:
            val_rmse = float("inf")
        else:
            m = compute_metrics(val_preds["actual"], val_preds["pred"])
            val_rmse = m["rmse"]
        results.append({"lr": lr, "dropout": dropout, "gcn_layers": gcn_layers, "val_rmse": val_rmse})
        print(f"  lr={lr} dropout={dropout} gcn_layers={gcn_layers} -> val RMSE={val_rmse:.3f}")

        if val_rmse < best_val_rmse:
            best_val_rmse = val_rmse
            best_cfg = cfg

    (OUT_DIR / "grid_search.json").write_text(json.dumps(results, indent=2))
    print(f"  best val RMSE={best_val_rmse:.3f} cfg={best_cfg}")
    return best_cfg


def main() -> None:
    ensure_dirs()
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    STGNN_DIR.mkdir(parents=True, exist_ok=True)
    set_seed()
    load_protocol()

    data = load_panel_tensors()
    countries = data["countries"]
    quarters = data["quarters"]
    split = data["split"]

    train_idx = timesteps_for_split(split, "train")
    val_idx = timesteps_for_split(split, "val")
    test_idx = timesteps_for_split(split, "test")

    x_raw = data["x"]
    y = data["y"]
    target_mask = data["target_mask"]
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    edge_indices, edge_weights = build_edge_lists(data["adj"], device)

    best_cfg = grid_search(
        x_raw, y, target_mask, train_idx, val_idx, edge_indices, edge_weights, device, x_raw.shape[-1]
    )

    print("\nPhase 1b: Rolling refit evaluation (val + test)...")
    eval_idx = sorted(list(val_idx) + list(test_idx))
    stgnn_fc = rolling_eval(
        x_raw, y, target_mask, edge_indices, edge_weights,
        eval_idx, best_cfg, device, countries, quarters,
        refit_epochs=30, verbose=True,
    )

    nodes = pd.read_csv(DATA_PROCESSED / "dataset_v1" / "nodes.csv")
    split_map = nodes.drop_duplicates("quarter").set_index("quarter")["split"]
    stgnn_fc["split"] = stgnn_fc["quarter"].map(split_map)
    stgnn_fc.to_csv(STGNN_DIR / "forecasts_rolling.csv", index=False)

    test_fc = stgnn_fc[stgnn_fc["split"] == "test"]
    val_fc = stgnn_fc[stgnn_fc["split"] == "val"]
    test_metrics = compute_metrics(test_fc["actual"], test_fc["stgnn_pred"])
    val_metrics = compute_metrics(val_fc["actual"], val_fc["stgnn_pred"])
    test_no_arg = test_fc[test_fc["iso3"] != "ARG"]
    test_metrics_no_arg = compute_metrics(test_no_arg["actual"], test_no_arg["stgnn_pred"])

    print(f"\nRolling refit ST-GNN test: RMSE={test_metrics['rmse']:.3f} MAE={test_metrics['mae']:.3f}")
    print(f"  (excl ARG): RMSE={test_metrics_no_arg['rmse']:.3f}")

    print("\nPhase 2: Diebold-Mariano tests...")
    baseline_fc = pd.read_csv(BASELINE_DIR / "forecasts.csv")
    merged = stgnn_fc.merge(
        baseline_fc[["iso3", "quarter", "arima_pred", "var_pred"]],
        on=["iso3", "quarter"],
        how="inner",
    )
    merged = merged[merged["split"] == "test"].dropna(subset=["stgnn_pred", "arima_pred", "var_pred"], how="any")

    dm_arima = diebold_mariano(
        merged["actual"].values, merged["stgnn_pred"].values, merged["arima_pred"].values, loss="squared"
    )
    dm_var = diebold_mariano(
        merged["actual"].values, merged["stgnn_pred"].values, merged["var_pred"].values, loss="squared"
    )
    dm_arima_mae = diebold_mariano(
        merged["actual"].values, merged["stgnn_pred"].values, merged["arima_pred"].values, loss="absolute"
    )

    baseline_metrics = json.loads((BASELINE_DIR / "metrics.json").read_text())

    report = {
        "run_at": datetime.now(timezone.utc).isoformat(),
        "milestone": 7,
        "phase1": {
            "loss": "Huber (Smooth L1)",
            "persistence_skip": True,
            "expanding_window_norm": True,
            "best_config": best_cfg.__dict__,
            "rolling_refit": True,
            "refit_epochs_per_step": 30,
        },
        "metrics": {
            "stgnn_rolling_val": val_metrics,
            "stgnn_rolling_test": test_metrics,
            "stgnn_rolling_test_excl_ARG": test_metrics_no_arg,
            "arima_test": baseline_metrics["arima"]["metrics"]["test"],
            "var_test": baseline_metrics["var"]["metrics"]["test"],
        },
        "diebold_mariano_test": {
            "stgnn_vs_arima_squared": dm_arima,
            "stgnn_vs_arima_absolute": dm_arima_mae,
            "stgnn_vs_var_squared": dm_var,
            "interpretation": "Negative DM stat => ST-GNN has lower average loss",
        },
        "target_rmse_under_4": test_metrics["rmse"] < 4.0,
        "paired_test_rows": len(merged),
    }
    (OUT_DIR / "evaluation_report.json").write_text(json.dumps(report, indent=2))
    merged.to_csv(OUT_DIR / "paired_forecasts_test.csv", index=False)

    print(f"\nSaved {OUT_DIR / 'evaluation_report.json'}")
    print("\n--- Test metrics ---")
    print(f"  ST-GNN (rolling): RMSE={test_metrics['rmse']:.3f} MAE={test_metrics['mae']:.3f}")
    print(f"  ARIMA:            RMSE={baseline_metrics['arima']['metrics']['test']['rmse']:.3f}")
    print(f"  VAR:              RMSE={baseline_metrics['var']['metrics']['test']['rmse']:.3f}")
    print("\n--- Diebold-Mariano (ST-GNN vs ARIMA, squared error) ---")
    print(f"  stat={dm_arima['statistic']:.3f}  p={dm_arima['p_value']:.4f}  n={dm_arima['n']}")
    print(f"  Target RMSE<4.0: {'YES' if report['target_rmse_under_4'] else 'NO'}")


if __name__ == "__main__":
    main()
